const form = document.getElementById("formAddItem");
const input = document.getElementById("inputItem");
const lista = document.getElementById("listaItens");
const select = document.getElementById("selectItens");

form.addEventListener("submit", function(event) {
    event.preventDefault();
    const texto = input.value.trim();
    if (texto === "") return;

    const li = document.createElement("li");
    li.textContent = texto;
    li.setAttribute("id", texto);
    lista.appendChild(li);

    const option = document.createElement("option");
    option.value = texto;
    option.text = texto;
    select.appendChild(option);

    input.value = "";
});

function marcarItem() {
    const valor = select.value;
    const item = document.getElementById(valor);
    if (item) {
        item.style.textDecoration = "color";
        item.style.color = "green";
    }
}

function desmarcarItem() {
    const valor = select.value;
    const item = document.getElementById(valor);
    if (item) {
        item.style.textDecoration = "none";
        item.style.color = "black";
    }
}

function removerItem() {
    const valor = select.value;
    const item = document.getElementById(valor);
    if (item) item.remove();

    const option = [...select.options].find(opt => opt.value === valor);
    if (option) option.remove();
}
